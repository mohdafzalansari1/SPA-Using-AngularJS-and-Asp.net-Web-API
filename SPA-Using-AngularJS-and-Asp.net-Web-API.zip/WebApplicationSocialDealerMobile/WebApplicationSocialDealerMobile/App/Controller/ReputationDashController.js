﻿
app.controller("ReputationDashController", function ($scope, ReputationDashFactory, $location) {
    $scope.message = "hi";
    $scope.IsMessageShow = false;
    $scope.dataLoading = true;
    var loginURL = "api/v1/reputation/dashboard";
    var AuthToken = window.localStorage['SDToken'];
    if (AuthToken==null)
    {
        $location.path('/login');
    }
    else {

        ReputationDashFactory.GetReputationDash(loginURL, AuthToken).then(function (response) {

            console.log(response);
            if (response.data.Code == "200") {

                $scope.Total = response.data.Data.Total;
                $scope.AvgRating = response.data.Data.AvgRating;

                $scope.ReputationDasboardData = response.data.Data.ReputationDasboardData;
                
            }
            else {
                $scope.message = response.data.Message;
            }
        }, function (error) {
            $scope.message = error.statusText;
        }).finally(function () {
            $scope.dataLoading = false;
        });
    }
    
});
