﻿
app.controller("AccountPickerController", function ($scope, AccountPickerFactory, $location) {
    $scope.message = "hi";
    $scope.IsMessageShow = false;

    var loginURL = "api/v1/account/GetRecentAccountList";
    var AuthToken = window.localStorage['SDToken'];
    if (AuthToken==null)
    {
        $location.path('/login');
    }
    else {

        AccountPickerFactory.GetAccountPickerData(loginURL, AuthToken).then(function (response) {

            console.log(response);
            if (response.data.Code == "200") {
                 $scope.RecentAccountList = response.data.Data;
                 $scope.IsMessageShow = false;
            }
            else {
                $scope.message = response.data.Message;
                $scope.IsMessageShow = true;
            }
        }, function (error) {
            $scope.message = response.data.Message;
            $scope.IsMessageShow = true;
        }).finally(function () {
        });

    }

    $scope.GetAccountPickerList = function (searchText){
        var loginURL = "api/v1/account/GetAccountPickList/" + searchText;
        AccountPickerFactory.GetAccountPickerData(loginURL, AuthToken).then(function (response) {

            console.log(response);
            if (response.data.Code == "200") {
                $scope.AccountPickerList = response.data.Data;
                $scope.IsMessageShow = false;
            }
            else {
                $scope.message = response.data.Message;
                $scope.IsMessageShow = true;
            }
        }, function (error) {
            $scope.message = error.statusText;
            $scope.IsMessageShow = true;
        }).finally(function () {
        });
    }


    

    $scope.AccountSwitcher = function (id) {
        alert(id);
        var UserName = "abhisheks6@chetu.com|";
        var auth = btoa(UserName + '1364982147157|01/24/2017 20:38:55|India Standard Time|Android');
        var loginURL = "api/v1/account/SwitchAccount/" + id + "/" + auth;

        AccountPickerFactory.GetAccountPickerData(loginURL, AuthToken).then(function (response) {

            console.log(response);
            if (response.data.Code == "200") {
                localStorage.clear();
                window.localStorage['SDToken'] = null;
                window.localStorage['SDToken'] = "";
                window.localStorage['SDToken'] = response.data.Data.AuthKey;
                $location.path('/dashboard');
            }
            else {
                $scope.message = response.data.Message;
                $scope.IsMessageShow = true;
            }
        }, function (error) {
            $scope.message = error.statusText;
            $scope.IsMessageShow = true;
        }).finally(function () {
        });
    }
    
});
