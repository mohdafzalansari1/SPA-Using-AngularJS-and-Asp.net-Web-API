﻿

app.controller("LoginController", function ($scope, LoginFactory, $location) {

    $scope.message = "";
    $scope.IsMessageShow = false;
    $scope.IsLoginButtonClicked = false;
    $scope.LoginButtonvalue = "Login";

    $scope.Login = function (User) {
        window.localStorage['SDToken'] = "QISQFioqrAMZylyxzQNGlJ9EtpkHBexwJwuz+4FeYcKrjuF+ia/M+T+pgbE5AhLJGhcv88vAMDy1Z0EEjlXg8SYtm1DHZtZ/tlsmBkdP/2hhLu9Ol8YqbD7iEEMYeXFb7rO0OV21fJBo8lZteZhVyW3xV5HldSLveg70+aqMilzQ4gHK4WZzJRdEUF2M1kqWAv2Mo5roMgojYUxPN1/QLGUvgnYzWxDGZtkTctKJsaO88ON4Xr8MDsdFg/QJ8d7FIbxRc9F1QR/fGqWBtwSv2slB25PsOaaI+6g8eKvwhBtgYxviqAGd76zfr0r1rpBLZYjUQqQor3qLH7mYKdNXwYDwKY7xSc3+YmdLVjgG6malcS9I7ktTwrrUS+c4fq6wqegnmYQVyglCk9mJetwbiOUPiJx1LHWa+NPyuYjr4Yvgwr1gVop/Fh6PlREwBLqYyC/0Q8NkjYBevwq7XELFfxuL35sIAG27FYqaGVJPpxuKTTQWS7cE5PJIBz2vvUDFwv0DXHC61quitgFEmiI8WWjK4ltAxGFIGI5We4zpYvO6RiPJNy6rjnWMZHEqp1A6jn8sdNvTPQ58T3eL2OUPHPd2ufXTbPwYKiUo4D3IRKA=";
        $scope.IsLoginButtonClicked = true;
        $scope.LoginButtonvalue = "Please wait..";
        var uID = User.UserName + "|";
        var pWD = User.Password + "|";
        var loginURL = "api/v1/account/login/QISQFioqrAMZylyxzQNGlJ9EtpkHBexwJwuz+4FeYcKrjuF+ia/M+T+pgbE5AhLJGhcv88vAMDy1Z0EEjlXg8SYtm1DHZtZ/tlsmBkdP/2hhLu9Ol8YqbD7iEEMYeXFb7rO0OV21fJBo8lZteZhVyYyjQOAMVMACFXT9+W2HLpBqWJGqNIaQeW9Ky1zvRQ6rVfsMtDf6A39+PB1oFA9s15TGRI4jc590pLuQt2Y14zxjH/Is4nx3zVnwkeBuwM/5wSFKqbtGyFxJgbQlUEZ81hyqpwgT4OmuGE/l3eW0YxE8FpVs1ce9dq3e10+GxcqSVLOyWNBktTWF7bcYAr3GOJSDNw+qEz6Gb178GsWE4C4DKsHDfuCZDgCai2h+ePzfvS2Z7Oj13LyqYj4/ez54hF7dD6RZUNH2N70J070lVbbyqbcZvJprJGGBWyIZF7FXDNuDS5iT6VmQzmalX0+fZhkdHkGlpD7KVdryrUbQmadKts1ls2YBkQ8vKwpFL9lNF2bFg2JcIohk5pvaun1pVgO6Vrrh1Rs/y51W6U5p41tfm4oDr8uRY+UrNkNIn838gMKIhoIKoktxqIGrQn7Kbn+xL3j+kVO7mRuV3igCEOo=";

        //LoginFactory.Login(loginURL).then(function (response) {
        //    if (response.data.Code=="200")
        //    {
        //        window.localStorage['SDToken'] = response.data.Data.AuthKey;
        //        $location.path('/dashboard');
        //    }
        //    else {
        //        $scope.message = response.data.Message;
        //        $scope.IsMessageShow = true;
        //        $scope.IsLoginButtonClicked = false;
        //        $scope.LoginButtonvalue = "login";
        //    }           
        //}, function (error) {
        //    $scope.message = error.statusText;
        //    $scope.IsMessageShow = true;
        //    $scope.LoginButtonvalue = "login";
        //}).finally(function () {

        //    $scope.IsLoginButtonClicked = false;
        //    $scope.LoginButtonvalue = "login";
        //});


           
    }
});


