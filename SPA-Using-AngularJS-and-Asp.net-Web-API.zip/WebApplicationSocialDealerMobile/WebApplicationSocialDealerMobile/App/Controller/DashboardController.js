﻿
app.controller("DashboardController",["$scope", "DashboardFactory", "$location", function ($scope, DashboardFactory, $location) {
    $scope.message = "hi";
    $scope.IsMessageShow = false;
    $scope.dataLoading = true;

    var loginURL = "api/v1/dashboard/main";
    var AuthToken = window.localStorage['SDToken'];
   
    if (AuthToken == null) {
        $location.path('/login');
    }
    else {
        LoadDashboardData();
    }

    function LoadDashboardData()
    {
        DashboardFactory.GetMainDashboardData(loginURL, AuthToken).then(function (response) {

            console.log(response);
            if (response.data.Code == "200") {

                $scope.NewNegativeReviews = response.data.Data.NewNegativeReviews;
                $scope.NewPositiveReviews = response.data.Data.NewPositiveReviews;

                $scope.TotalEngagements = response.data.Data.TotalEngagements;
                $scope.Impressions = response.data.Data.Impressions;
                $scope.TotalNew = response.data.Data.TotalNew;
            }
            else {
                $scope.message = response.data.Message;
            }
        }, function (error) {
            $scope.message = error.statusText;
        }).finally(function () {
            $scope.dataLoading = false;
        });
    }

    

   
    
}]);
