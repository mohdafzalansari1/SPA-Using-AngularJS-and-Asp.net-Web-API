﻿
app.controller("SocialDashController", function ($scope, SocialDashFactory, $location) {
    $scope.message = "hi";
    $scope.IsMessageShow = false;
    $scope.dataLoading = true;
    var loginURL = "api/v1/social/dashboard";
    var AuthToken = window.localStorage['SDToken'];
    if (AuthToken==null)
    {
        $location.path('/login');
    }
    else {

        SocialDashFactory.GetSocialDash(loginURL, AuthToken).then(function (response) {

            console.log(response);
            if (response.data.Code == "200") {

                $scope.EngagementPostRate = response.data.Data.socialDashOverview.EngagementPostRate;
                $scope.EngagementRate = response.data.Data.socialDashOverview.EngagementRate;
                $scope.SocialAudiance = response.data.Data.socialDashOverview.SocialAudiance;
                $scope.socialListData = response.data.Data.socialData;               
            }
            else {
                $scope.message = response.data.Message;
            }
        }, function (error) {
            $scope.message = error.statusText;
        }).finally(function () {
            $scope.dataLoading = false;
        });
    }
    
});
