﻿
app.controller("ProcesionDashController", function ($scope, ProcesionDashFactory, $location) {

    $scope.dataLoading = true;
   
    $scope.message = "hi";
    $scope.IsMessageShow = false;
    var loginURL = "api/v1/procision/dashboard";
    var AuthToken = window.localStorage['SDToken'];
    alert(AuthToken)
    if (AuthToken==null)
    {
        $location.path('/login');
    }
    else {
        ProcesionDashFactory.GetProcesionDash(loginURL, AuthToken).then(function (response) {
            console.log(response);
            if (response.data.Code == "200") {

                $scope.ProcAggregateOfInsights = response.data.Data.aggregateOfInsights;
                $scope.ProcCountOfSets = response.data.Data.countOfSets;
                $scope.ProcMatchedSalesAggregate = response.data.Data.matchedSalesAggregate;
                $scope.ProcMatchedServicesAggregate = response.data.Data.matchedServicesAggregate;
            }
            else {
                $scope.message = response.data.Message;
            }
        }).finally(function () {
            $scope.dataLoading = false;
        });       
    }
});
