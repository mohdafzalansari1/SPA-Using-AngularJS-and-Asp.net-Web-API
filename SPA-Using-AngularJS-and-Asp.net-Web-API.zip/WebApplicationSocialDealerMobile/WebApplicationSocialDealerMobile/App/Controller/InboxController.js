﻿
app.controller("InboxController", ['$scope', 'InboxFactory', '$location', function ($scope, InboxFactory, $location) {
    $scope.message = "hi";
    $scope.IsMessageShow = false;
    $scope.dataLoading = true;
    $scope.IsShowInbox = true;
    var loginURL = "api/v1/inbox/all";

    var AuthToken = window.localStorage['SDToken'];
    $scope.itemLength = 0;

    //Load All Inbox list 
    LoadInboxlist();
    function LoadInboxlist()
    {
        if (AuthToken == null) {
            $location.path('/login');
        }
        else {

            InboxFactory.GetInbox(loginURL, AuthToken).then(function (response) {
                console.log(response);
                if (response.data.Code == "200") {

                    $scope.inboxlist = response.data.Data;
                    $scope.itemLength = $scope.inboxlist.length;

                    $scope.totalItems = $scope.itemLength;
                    $scope.currentPage = 1;
                    $scope.itemsPerPage = 5;
                    $scope.maxSize = 5;
                }
                else {
                    $scope.message = response.data.Message;
                }
            }, function (error) {
                $scope.message = error.statusText;
            }).finally(function () {
                $scope.dataLoading = false;
            });
        }
    }
   
   

    $scope.setPage = function (pageNo) {
        $scope.currentPage = pageNo;
    };

    $scope.pageChanged = function () {
        console.log('Page changed to: ' + $scope.currentPage);
    };

    $scope.setItemsPerPage = function (num) {
        $scope.itemsPerPage = num;
        $scope.currentPage = 1; //reset to first paghe
    }


    $scope.InboxDetails = function (inbox) {
        var type="";
        var inboxDetails = inbox.Id;
        if (inbox.Type == "Unread")
        {
            type = "reputation";
        }            
        else if (inbox.Type == "PendingApproval")
        {
            type = "social";
        }

        loginURL = "api/v1/inbox/" + inbox.Id + "/" + type;
        InboxFactory.GetInboxDetails(loginURL, AuthToken).then(function (response) {
            console.log(response);
            if (response.data.Code == "200") {

                $scope.inboxDetails = response.data.Data;
                console.log($scope.inboxlist);
                $scope.IsShowInbox = false;
            }
            else {
                $scope.message = response.data.Message;
                console.log($scope.message);
            }
        }, function (error) {
            $scope.message = error.statusText;
            console.log($scope.message);
        }).finally(function () {
            $scope.dataLoading = false;
        });
    }

    $scope.MarkedAsread = function (inboxDetails) {
       
        //api/v1/inbox/markread/{inboxAccountId}/{reviewId}
        loginURL = "api/v1/inbox/markread/" + inboxDetails.AccountId + "/" + inboxDetails.ReviewID;
        InboxFactory.PostMarkedAsread(loginURL, AuthToken).then(function (response) {
            console.log(response);
            if (response.data.Code == "200") {

                $scope.inboxDetails = response.data.Data;
                console.log($scope.inboxlist);
                $scope.IsShowInbox = true;
            }
            else {
                $scope.message = response.data.Message;
                console.log($scope.message);
            }
        }, function (error) {
            $scope.message = error.statusText;
            console.log($scope.message);
        }).finally(function () {
            $scope.dataLoading = false;
        });
    }

    $scope.MarkedCancale = function () {
        
       
        LoadInboxlist();
        $scope.IsShowInbox = true;
    }

}]);
