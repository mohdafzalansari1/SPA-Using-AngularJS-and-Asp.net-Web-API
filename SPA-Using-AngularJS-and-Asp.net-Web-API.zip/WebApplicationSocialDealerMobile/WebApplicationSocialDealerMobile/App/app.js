﻿/// <reference path="c:\users\mohda6\documents\visual studio 2015\Projects\WebApplicationSocialDealerMobile\WebApplicationSocialDealerMobile\Script/angular-route.js" />
/// <reference path="c:\users\mohda6\documents\visual studio 2015\Projects\WebApplicationSocialDealerMobile\WebApplicationSocialDealerMobile\Script/angular.js" />

var app = angular.module("SDApp", ["ui.bootstrap", "ngRoute"]);

app.config(function ($routeProvider, $locationProvider) {
    $routeProvider.when('/login', {
        templateUrl: 'Templates/Login.html',
        controller: 'LoginController',
    }).when('/dashboard', {
        templateUrl: 'Templates/Dashboard.html',
        controller: 'DashboardController',
    }).when('/reputation', {
        templateUrl: 'Templates/ReputationDash.html',
        controller: 'ReputationDashController',
    }).when('/social', {
        templateUrl: 'Templates/SocialDash.html',
        controller: 'SocialDashController',
    }).when('/procesion', {
        templateUrl: 'Templates/ProcesionDash.html',
        controller: 'ProcesionDashController',
    }).when('/inbox', {
        templateUrl: 'Templates/Inbox.html',
        controller: 'InboxController',
    }).when('/accountChnage', {
        templateUrl: 'Templates/AccountPicker.html',
        controller: 'AccountPickerController',
    }).otherwise({
        redirectTo: "/login"
    })

    //$locationProvider.html5Mode(true)

});