﻿

app.factory("ReputationDashFactory", function ($http) {

    var reputationDashFactory = {};
    var port = "https://mobilesvc.socialdealer.com/";

    reputationDashFactory.GetReputationDash = function (url, token) {
        return $http({
            method: 'GET',
            url: port + url,
            headers: {               
                'X-Auth': token
            }
        });
    }
    return reputationDashFactory;
});