﻿

app.factory("LoginFactory", function ($http) {

    var loginFactory = {};
    var port = "https://mobilesvc.socialdealer.com/";

    loginFactory.Login = function (url) {
        alert(url);
        return $http({
            method: 'POST',
            url: port + url           
        });
    }

    return loginFactory;
});