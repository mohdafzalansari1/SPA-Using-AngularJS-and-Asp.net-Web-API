﻿

app.factory("InboxFactory", function ($http) {

    var inboxFactory = {};
    var port = "https://mobilesvc.socialdealer.com/";

    inboxFactory.GetInbox = function (url, token) {
        return $http({
            method: 'GET',
            url: port + url,
            headers: {               
                'X-Auth': token
            }
        });
    }
    inboxFactory.GetInboxDetails = function (url, token) {
        return $http({
            method: 'GET',
            url: port + url,
            headers: {
                'X-Auth': token
            }
        });
    }
    inboxFactory.PostMarkedAsread = function (url, token) {
        return $http({
            method: 'GET',
            url: port + url,
            headers: {
                'X-Auth': token
            }
        });
    }

    return inboxFactory;
});