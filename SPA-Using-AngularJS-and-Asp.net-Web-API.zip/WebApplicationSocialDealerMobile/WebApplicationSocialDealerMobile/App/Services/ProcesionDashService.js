﻿

app.factory("ProcesionDashFactory", function ($http) {

    var procesionDashFactory = {};
    var port = "https://mobilesvc.socialdealer.com/";

    procesionDashFactory.GetProcesionDash = function (url, token) {
        return $http({
            method: 'GET',
            url: port + url,
            headers: {               
                'X-Auth': token
            }
        });
    }
    return procesionDashFactory;
});