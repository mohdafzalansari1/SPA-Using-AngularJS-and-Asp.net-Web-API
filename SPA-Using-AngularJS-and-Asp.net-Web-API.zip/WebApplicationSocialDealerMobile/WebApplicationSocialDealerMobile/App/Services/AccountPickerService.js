﻿

app.factory("AccountPickerFactory", function ($http) {

    var accountPicker = {};
    var port = "https://mobilesvc.socialdealer.com/";

    accountPicker.GetAccountPickerData = function (url, token) {
        return $http({
            method: 'POST',
            url: port + url,
            headers: {               
                'X-Auth': token
            }
        });
    }

    accountPicker.AccountSwitcher = function (url, token) {
        return $http({
            method: 'POST',
            url: port + url,
            headers: {
                'X-Auth': token
            }
        });
    }

    accountPicker.AccountSwitcher = function (url, token) {
        return $http({
            method: 'POST',
            url: port + url,
            headers: {
                'X-Auth': token
            }
        });
    }
    return accountPicker;
});