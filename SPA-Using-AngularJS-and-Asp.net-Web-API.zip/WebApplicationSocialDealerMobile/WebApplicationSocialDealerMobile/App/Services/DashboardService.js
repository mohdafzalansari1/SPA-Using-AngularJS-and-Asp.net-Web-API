﻿

app.factory("DashboardFactory", function ($http) {

    var dashboardFactory = {};
    var port = "https://mobilesvc.socialdealer.com/";

    dashboardFactory.GetMainDashboardData = function (url, token) {
        return $http({
            method: 'GET',
            url: port + url,
            headers: {               
                'X-Auth': token
            }
        });
    }
    return dashboardFactory;
});