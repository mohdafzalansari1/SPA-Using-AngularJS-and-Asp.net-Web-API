﻿

app.factory("SocialDashFactory", function ($http) {

    var socialDashFactory = {};
    var port = "https://mobilesvc.socialdealer.com/";

    socialDashFactory.GetSocialDash = function (url, token) {
        return $http({
            method: 'GET',
            url: port + url,
            headers: {               
                'X-Auth': token
            }
        });
    }
    return socialDashFactory;
});